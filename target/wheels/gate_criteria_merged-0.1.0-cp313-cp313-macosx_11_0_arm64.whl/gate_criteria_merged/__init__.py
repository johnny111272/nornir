from .gate_criteria_merged import *

__doc__ = gate_criteria_merged.__doc__
if hasattr(gate_criteria_merged, "__all__"):
    __all__ = gate_criteria_merged.__all__