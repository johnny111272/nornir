from .gate_permissions_resolved_output import *

__doc__ = gate_permissions_resolved_output.__doc__
if hasattr(gate_permissions_resolved_output, "__all__"):
    __all__ = gate_permissions_resolved_output.__all__