from .gate_instructions_reduced import *

__doc__ = gate_instructions_reduced.__doc__
if hasattr(gate_instructions_reduced, "__all__"):
    __all__ = gate_instructions_reduced.__all__