from .gate_permissions_resolved_input import *

__doc__ = gate_permissions_resolved_input.__doc__
if hasattr(gate_permissions_resolved_input, "__all__"):
    __all__ = gate_permissions_resolved_input.__all__