from .gate_examples_reduced import *

__doc__ = gate_examples_reduced.__doc__
if hasattr(gate_examples_reduced, "__all__"):
    __all__ = gate_examples_reduced.__all__